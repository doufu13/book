from selenium import webdriver

def getPic(url):
    urlCrawler = urlroot + url
    urlName = url.replace("/","_")
    driver = webdriver.Firefox()
    try:
        driver.get(urlCrawler)
        driver.get_screenshot_as_file("./pics/"+urlName+".png")
    except Exception  as e:
        print(e)
    finally:
        driver.close()
    
    
    

urlroot = "http://192.168.1.106:8080/"
with open("jiraurl") as f:
    for line in f:
        url = line.strip()[13:-14]
        if "*" in url:
            pass
        else:
            print(url)
            getPic(url)

